Beam Splitter
=============

.. automodule:: sequence.components.beam_splitter
    :members:
