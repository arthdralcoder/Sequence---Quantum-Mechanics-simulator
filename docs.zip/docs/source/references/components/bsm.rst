BSM
===

.. automodule:: sequence.components.bsm
    :members:

