Circuit
=======

.. automodule:: sequence.components.circuit
    :members: