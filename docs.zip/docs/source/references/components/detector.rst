Detector
========

.. automodule:: sequence.components.detector
    :members:
