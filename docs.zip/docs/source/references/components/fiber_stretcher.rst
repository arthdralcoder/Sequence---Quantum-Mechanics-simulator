Fiber Stretcher
===============

.. automodule:: sequence.components.fiber_stretcher
    :members: