Light Source
============

.. automodule:: sequence.components.light_source
    :members:
