Optical Channel
===============

.. automodule:: sequence.components.optical_channel
    :members:
