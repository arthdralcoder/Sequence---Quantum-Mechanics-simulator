Photon
======

.. automodule:: sequence.components.photon
    :members:
