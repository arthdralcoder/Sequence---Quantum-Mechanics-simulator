Switch
======

.. automodule:: sequence.components.switch
    :members:
