Entanglement Swapping
=====================

.. automodule:: sequence.entanglement_management.swapping
    :members:
