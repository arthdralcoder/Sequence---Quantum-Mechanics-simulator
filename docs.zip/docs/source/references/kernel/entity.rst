Entity
======

.. automodule:: sequence.kernel.entity
    :members:
