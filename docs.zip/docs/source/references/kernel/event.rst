Event
=====

.. automodule:: sequence.kernel.event
    :members:
