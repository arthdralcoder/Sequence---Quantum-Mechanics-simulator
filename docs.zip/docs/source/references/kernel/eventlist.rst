Event List
==========

.. automodule:: sequence.kernel.eventlist
    :members:
