Quantum Manager
===============

.. automodule:: sequence.kernel.quantum_manager
    :members:
