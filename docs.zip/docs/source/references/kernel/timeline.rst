Timeline
========

.. automodule:: sequence.kernel.timeline
    :members:
