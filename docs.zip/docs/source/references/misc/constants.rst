Constants
========

.. automodule:: sequence.constants
    :members:
