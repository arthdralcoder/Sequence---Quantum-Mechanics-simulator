Message
=======

.. automodule:: sequence.message
    :members:
