Protocol
========

.. automodule:: sequence.protocol
    :members:
