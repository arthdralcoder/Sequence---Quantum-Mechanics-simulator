Miscellaneous
=============

Miscellaneous SeQUeNCe modules.

.. toctree::
    :maxdepth: 2

    constants
    message
    protocol
    utils/top
