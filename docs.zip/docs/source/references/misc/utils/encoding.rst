Encoding
========

.. automodule:: sequence.utils.encoding
    :members:
