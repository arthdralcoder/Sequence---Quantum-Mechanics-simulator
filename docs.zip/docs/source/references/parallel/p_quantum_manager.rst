Parallel Quantum Manager
============================

.. automodule:: parallel.src.p_quantum_manager
    :members:
