Parallel Router Net Topology
============================

.. automodule:: parallel.src.p_router_net_topo
    :members:
