Quantum Manager Client
======================

.. automodule:: parallel.src.quantum_manager_client
    :members:
