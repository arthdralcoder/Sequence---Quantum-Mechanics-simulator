Resource Management
===================

The Resource Management module is responsible for managing the local resources (usually quantum memories) of a node.

.. toctree::
    :maxdepth: 2

    resource_manager
    memory_manager
    rule_manager
