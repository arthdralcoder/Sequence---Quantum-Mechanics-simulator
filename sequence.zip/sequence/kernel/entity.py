"""
Definition of abstract Entity class with latency tracking.

This module defines the Entity class, inherited by all physical simulation elements (including hardware and photons),
with added functionality to track and calculate latency.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Dict, List
from numpy.random import default_rng
from numpy.random._generator import Generator
from time import perf_counter  # Used to measure latency

if TYPE_CHECKING:
    from .timeline import Timeline
    from ..components.photon import Photon


class Entity(ABC):
    """Abstract Entity class with latency tracking.
    
    Entity instances track and measure latency in interactions, 
    ensuring simulation reproducibility with a pseudo-random number generator (PRNG).
    
    Attributes:
        name (str): name of the entity.
        timeline (Timeline): the simulation timeline for the entity.
        owner (Entity): another entity that owns or aggregates the current entity.
        _observers (List): a list of observers for the entity.
        _receivers (List[Entity]): entities that receive photons from the current component.
        latency (Dict[Entity, float]): latency measured for each receiving entity.
    """

    def __init__(self, name: str, timeline: "Timeline") -> None:
        """Constructor for the Entity class.
        
        Args:
            name (str): name of entity.
            timeline (Timeline): timeline for simulation.
        """
        self.name = "" if name is None else name
        self.timeline = timeline
        self.owner = None

        self._receivers: List[Entity] = []
        self._observers: List[Any] = []
        self.latency: Dict[Entity, float] = {}  # Dictionary to store latency for each receiver

        timeline.add_entity(self)

    def __str__(self) -> str:
        return self.name

    @abstractmethod
    def init(self) -> None:
        """Abstract method to initialize the entity.
        
        Called for all entities when the timeline is initialized, allowing necessary pre-simulation setup.
        """
        pass

    def add_receiver(self, receiver: "Entity") -> None:
        """Adds a receiving entity to track interactions and latency with."""
        self._receivers.append(receiver)

    def attach(self, observer: Any) -> None:
        """Adds an observer to receive updates on the entity's state."""
        if observer not in self._observers:
            self._observers.append(observer)

    def detach(self, observer: Any) -> None:
        """Removes an observer."""
        self._observers.remove(observer)

    def notify(self, info: Dict[str, Any]) -> None:
        """Notifies all attached observers of an update."""
        for observer in self._observers:
            observer.update(self, info)

    def send_photon(self, photon: "Photon", receiver: "Entity", **kwargs) -> None:
        """Sends a photon to a receiver entity, measuring latency."""
        start_time = perf_counter()  # Start latency timer

        receiver.get(photon, **kwargs)  # Send photon

        end_time = perf_counter()  # End latency timer
        self.latency[receiver] = end_time - start_time  # Calculate and store latency

    def get(self, photon: "Photon", **kwargs):
        """Receives a photon, to be implemented in subclasses.
        
        Args:
            photon (Photon): Photon received by the entity.
            **kwargs: Additional arguments specific to the hardware component.
        """
        raise Exception("get method called on non-receiving class.")

    def remove_from_timeline(self) -> None:
        """Removes the entity from the timeline, allowing for garbage collection."""
        self.timeline.remove_entity_by_name(self.name)

    def get_generator(self) -> Generator:
        """Returns the PRNG generator of the parent node if attached, or a default generator."""
        if hasattr(self.owner, "get_generator"):
            return self.owner.get_generator()
        else:
            return default_rng()

    def change_timeline(self, timeline: "Timeline"):
        """Changes the simulation timeline for the entity."""
        self.remove_from_timeline()
        self.timeline = timeline
        self.timeline.add_entity(self)
