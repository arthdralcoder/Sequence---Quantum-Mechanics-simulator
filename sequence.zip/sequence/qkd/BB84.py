from mailbox import Message
import numpy as np
from sequence.protocol import StackProtocol


class BB84(StackProtocol):
    def __init__(self,owner, name, lightsource, qsdetector,*args, **kwargs):
        super().__init__(owner,name,*args, **kwargs)
        self.lightsource = lightsource
        self.qsdetector = qsdetector
        self.dynamic_threshold = 0.1  # Starting threshold for error rate
       
    def adjust_threshold(self, observed_error_rate):
        #Dynamically adjust error threshold based on observed error rates.
        if observed_error_rate > self.dynamic_threshold: # type: ignore
            self.dynamic_threshold = min(1.0, self.dynamic_threshold + 0.05)  # Increase threshold
        else:
            self.dynamic_threshold = max(0.05, self.dynamic_threshold - 0.05)  # Decrease threshold

    def received_message(self, src: str, msg: Message):
        #Handle incoming messages.
        if msg.msg_type == BB84MsgType.MATCHING_INDICES:  # Ensure the correct comparison operator
            indices = msg.indices
            bits = self.bit_lists.pop(0)

            # Calculate observed error rate based on matching indices
            observed_error_rate = self.calculate_error_rate(bits, indices)

            # Adjust threshold based on observed error rate
            self.adjust_threshold(observed_error_rate)

            if observed_error_rate <= self.dynamic_threshold:
                # Process bits normally
                self.key_bits.extend([bits[i] for i in indices])
            else:
                # Log a warning if the observed error rate is too high
                print(f"Warning: Error rate {observed_error_rate} exceeds threshold {self.dynamic_threshold}")

    def calculate_error_rate(self, bits, indices):
        """Calculate the error rate between bits and matching indices."""
        errors = sum(1 for i in indices if bits[i] == -1)  # Assuming -1 marks errors
        return errors / len(indices) if indices else 0  # Return 0 if no indices are provided


# Example BB84 message type definition (replace this as necessary in your code)
class BB84MsgType:
    MATCHING_INDICES = 1  # Example message type for matching indices
