import argparse
import json
from jsonschema import validate, ValidationError
from graphviz import Graph
from collections import defaultdict

from sequence.topology.router_net_topo import RouterNetTopo
from sequence.topology.qkd_topo import QKDTopo

# JSON schema to validate the input configuration
NETWORK_SCHEMA = {
    "type": "object",
    "properties": {
        "nodes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "type": {"type": "string"},
                    "color": {"type": "string", "default": "black"},
                    "shape": {"type": "string", "default": "ellipse"}
                },
                "required": ["name", "type"]
            }
        },
        "qchannels": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "sender": {"type": "string"},
                    "receiver": {"type": "string"},
                    "color": {"type": "string", "default": "blue"},
                    "style": {"type": "string", "default": "solid"}
                },
                "required": ["sender", "receiver"]
            }
        }
    },
    "required": ["nodes", "qchannels"]
}


def load_config(config_file):
    try:
        with open(config_file, 'r') as fh:
            config = json.load(fh)
            validate(instance=config, schema=NETWORK_SCHEMA)
        return config
    except (json.JSONDecodeError, ValidationError) as e:
        raise Exception(f"Invalid JSON file: {e}")


def create_topology(config, draw_middle):
    nodes = config["nodes"]
    node_type = nodes[0]["type"]

    if node_type == RouterNetTopo.BSM_NODE or node_type == RouterNetTopo.QUANTUM_ROUTER:
        return RouterNetTopo(config)
    elif node_type == QKDTopo.QKD_NODE:
        return QKDTopo(config)
    else:
        raise Exception(f"Unknown node type '{node_type}' in config file")


def add_nodes(g, topo, draw_middle):
    for node in topo.nodes.values():
        shape = node.get("shape", "ellipse")
        color = node.get("color", "black")
        g.node(node['name'], shape=shape, color=color)
        if draw_middle and node["type"] == RouterNetTopo.BSM_NODE:
            g.node(node['name'], label='BSM', shape='rectangle')


def add_edges(g, topo, draw_middle):
    if draw_middle:
        for qchannel in topo.get_qchannels():
            g.edge(qchannel.sender.name, qchannel.receiver, color=qchannel.color, style=qchannel.style)
    else:
        bsm_to_node = defaultdict(list)
        for qchannel in topo.get_qchannels():
            bsm_to_node[qchannel.receiver].append(qchannel.sender.name)
        for bsm, nodes in bsm_to_node.items():
            if len(nodes) == 2:
                g.edge(nodes[0], nodes[1], color="blue")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('config_file', help="path to json file defining network")
    parser.add_argument('-d', '--directory', type=str, default='tmp', help='directory to save the figure')
    parser.add_argument('-f', '--filename', type=str, default='topology', help='filename of the figure')
    parser.add_argument('-m', '--draw_middle', action='store_true')
    parser.add_argument('--format', type=str, default='png', choices=['png', 'svg', 'pdf'], help='output format')

    args = parser.parse_args()
    directory = args.directory
    filename = args.filename
    draw_middle = args.draw_middle
    output_format = args.format

    # Load and validate config
    config = load_config(args.config_file)

    # Determine network type and create topology
    topo = create_topology(config, draw_middle)

    # Create Graph
    g = Graph(format=output_format)
    g.attr(layout='neato', overlap='false')

    # Add nodes and edges
    add_nodes(g, topo, draw_middle)
    add_edges(g, topo, draw_middle)

    # Render graph
    g.view(directory=directory, filename=filename)


if __name__ == "__main__":
    main()
